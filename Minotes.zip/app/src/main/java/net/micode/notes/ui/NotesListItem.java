/*
 * Copyright (c) 2010-2011, The MiCode Open Source Community (www.micode.net)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.micode.notes.ui;

import android.content.Context;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import net.micode.notes.R;
import net.micode.notes.data.Notes;
import net.micode.notes.tool.DataUtils;
import net.micode.notes.tool.ResourceParser.NoteItemBgResources;

import java.security.MessageDigest;


public class NotesListItem extends LinearLayout {
    private ImageView mAlert;
    private TextView mTitle;
    private TextView mTime;
    private TextView mCallName;
    private NoteItemData mItemData;
    private CheckBox mCheckBox;

    public NotesListItem(Context context) {
        super(context);
        inflate(context, R.layout.note_item, this);
        mAlert = (ImageView) findViewById(R.id.iv_alert_icon);
        mTitle = (TextView) findViewById(R.id.tv_title);
        mTime = (TextView) findViewById(R.id.tv_time);
        mCallName = (TextView) findViewById(R.id.tv_name);
        mCheckBox = (CheckBox) findViewById(android.R.id.checkbox);
    }

    private String xorEncryptDecrypt(String input, String key) {
        if(input==null || key==null)
            return input;
        StringBuilder output = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            output.append((char) (input.charAt(i) ^ key.charAt(i % key.length())));
        }
        return output.toString();
    }

    public void bind(Context context, NoteItemData data, boolean choiceMode, boolean checked) {
        if (choiceMode && data.getType() == Notes.TYPE_NOTE) {
            mCheckBox.setVisibility(View.VISIBLE);
            mCheckBox.setChecked(checked);
        } else {
            mCheckBox.setVisibility(View.GONE);
        }

        mItemData = data;
        if (data.getId() == Notes.ID_CALL_RECORD_FOLDER) {
            mCallName.setVisibility(View.GONE);
            mAlert.setVisibility(View.VISIBLE);
            mTitle.setTextAppearance(context, R.style.TextAppearancePrimaryItem);
            mTitle.setText(context.getString(R.string.call_record_folder_name)
                    + context.getString(R.string.format_folder_files_count, data.getNotesCount()));
            mAlert.setImageResource(R.drawable.call_record);
        } else if (data.getParentId() == Notes.ID_CALL_RECORD_FOLDER) {
            mCallName.setVisibility(View.VISIBLE);
            mCallName.setText(data.getCallName());
            mTitle.setTextAppearance(context,R.style.TextAppearanceSecondaryItem);
            mTitle.setText(DataUtils.getFormattedSnippet(data.getSnippet()));
            if (data.hasAlert()) {
                mAlert.setImageResource(R.drawable.clock);
                mAlert.setVisibility(View.VISIBLE);
            } else {
                mAlert.setVisibility(View.GONE);
            }
        } else {
            mCallName.setVisibility(View.GONE);
            mTitle.setTextAppearance(context, R.style.TextAppearancePrimaryItem);

            if (data.getType() == Notes.TYPE_FOLDER) {
                mTitle.setText(data.getSnippet()
                        + context.getString(R.string.format_folder_files_count,
                        data.getNotesCount()));
                mAlert.setVisibility(View.GONE);
            } else {
                mTitle.setText(DataUtils.getFormattedSnippet(data.getSnippet()));
                if (data.hasAlert()) {
                    mAlert.setImageResource(R.drawable.clock);
                    mAlert.setVisibility(View.VISIBLE);
                } else {
                    mAlert.setVisibility(View.GONE);
                }
            }
        }
        mTime.setText(DateUtils.getRelativeTimeSpanString(data.getModifiedDate()));


        String originalText = data.getSnippet(); // 假设原文本来自笔记的摘要

        //xor解密
        String key=NotesListActivity.password_user;
        String decryptText=xorEncryptDecrypt(originalText,key);

        boolean flag=false;
        //检查是否重复
        for(int i=0;i<NotesListActivity.all_texts.length;i++){
            if(NotesListActivity.all_texts[i].equals(decryptText)){
                flag=true;
                break;
            }
        }

        //检查是否有字段是当前文本的前缀
        if(!flag)
        {
            for (int i = 0; i < NotesListActivity.all_texts.length; i++) {
                if (decryptText.startsWith(NotesListActivity.all_texts[i])) {
                    //使用正则表达式识别出多出的部分是否以[loacl]开头和[/local]结尾
                    String regex = "^\\[local\\].*\\[/local\\]$";

                    //取出多的部分
                    String extra = decryptText.replace(NotesListActivity.all_texts[i], "");
                    //String extra= decryptText.substring(decryptText.length()- NotesListActivity.all_texts[i].length());
                    Log.d("NoteListItem", "extra:" + extra);
                    if (extra.matches(regex)) {
                        //如果多出的部分是以[local]开头和结尾的，那么之前存在的就是重复的,更换之前的即可
                        NotesListActivity.all_texts[i] = decryptText;
                        NotesListActivity.Nodelist[i] = data;
                        flag = true;
                        break;
                    }
                }
            }
        }

        if(!flag) {
            String[] new_list = new String[NotesListActivity.all_texts.length + 1];
            for (int i = 0; i < NotesListActivity.all_texts.length; i++) {
                new_list[i] = NotesListActivity.all_texts[i];
            }
            new_list[NotesListActivity.all_texts.length] = decryptText;
            NotesListActivity.all_texts = new_list;


            NoteItemData[] new_list2 = new NoteItemData[NotesListActivity.Nodelist.length + 1];
            for (int i = 0; i < NotesListActivity.Nodelist.length; i++) {
                new_list2[i] = NotesListActivity.Nodelist[i];
            }
            new_list2[NotesListActivity.Nodelist.length] = data;
            NotesListActivity.Nodelist = new_list2;
        }

        /*
        //将原文本的hashCode作为标题

        int hashCode = originalText.hashCode();
        String hashString = String.valueOf(hashCode);

        mTitle.setText(hashString);       //hash值标题
         */


        mTitle.setText(decryptText);      //解密标题


        setBackground(data);
    }

    private void setBackground(NoteItemData data) {
        int id = data.getBgColorId();
        if (data.getType() == Notes.TYPE_NOTE) {
            if (data.isSingle() || data.isOneFollowingFolder()) {
                setBackgroundResource(NoteItemBgResources.getNoteBgSingleRes(id));
            } else if (data.isLast()) {
                setBackgroundResource(NoteItemBgResources.getNoteBgLastRes(id));
            } else if (data.isFirst() || data.isMultiFollowingFolder()) {
                setBackgroundResource(NoteItemBgResources.getNoteBgFirstRes(id));
            } else {
                setBackgroundResource(NoteItemBgResources.getNoteBgNormalRes(id));
            }
        } else {
            setBackgroundResource(NoteItemBgResources.getFolderBgRes());
        }
    }

    public NoteItemData getItemData() {
        return mItemData;
    }
}