package net.micode.notes.ui;
import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.Filter;

import java.util.ArrayList;
import java.util.List;





public class CustomArrayAdapter extends ArrayAdapter<String> {

    private List<String> originalData;
    private List<String> filteredData;

    public CustomArrayAdapter(Context context, int textViewResourceId, List<String> data) {
        super(context, textViewResourceId, data);
        this.originalData = new ArrayList<>(data);
        this.filteredData = new ArrayList<>(data);
    }


    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                FilterResults results = new FilterResults();
                if (constraint == null || constraint.length() == 0) {
                    results.values = originalData;
                    results.count = originalData.size();
                } else {
                    String filterString = constraint.toString().toLowerCase();
                    List<String> filterResultsData = new ArrayList<>();

                    for (String data : originalData) {
                        // 你自己的搜索匹配逻辑
                        if (yourCustomMatchFunction(data, filterString)) {
                            filterResultsData.add(data);
                        }
                    }

                    results.values = filterResultsData;
                    results.count = filterResultsData.size();
                }
                return results;
            }

            @SuppressWarnings("unchecked")
            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                filteredData = (List<String>) results.values;
                clear();
                addAll(filteredData);
                notifyDataSetChanged();
            }
        };
    }

    // 提供你自己的匹配逻辑
    private boolean yourCustomMatchFunction(String data, String filterString) {
        return AmbiguousMatch.compare(data, filterString);
        // 自定义匹配代码，返回true或false
    }
}

