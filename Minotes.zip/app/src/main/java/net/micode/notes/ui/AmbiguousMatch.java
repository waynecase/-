package net.micode.notes.ui;

import java.util.HashSet;

public final class AmbiguousMatch {
    private static boolean hasIntersection(String[] array1, String[] array2) {
        HashSet<String> set = new HashSet<>();
        for (String s : array1) {
            set.add(s);
        }
        for (String s : array2) {
            if (set.contains(s)) {
                return true;
            }
        }
        return false;
    }

    public static boolean compare(String a, String b) {
        final String[] key_a = a.split("\\W+"), key_b = b.split("\\W+");
        return hasIntersection(key_a, key_b);
    }

    // public static void main(String[] args) {
    //     System.out.println(compare("A quick brown fox jumps over the lazy dog.", "jump over"));
    // }
}