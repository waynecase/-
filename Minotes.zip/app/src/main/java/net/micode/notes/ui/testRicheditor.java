package net.micode.notes.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;

import jp.wasabeef.richeditor.RichEditor;

public class testRicheditor extends RichEditor
{


    public testRicheditor(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public void clearTextBackgroundColor() {
        //清除背景颜色
        this.exec("javascript:RE.prepareInsert();");
        this.exec("javascript:RE.removeTextBackgroundColor();");

        this.exec("javascript:RE.clearTextBackgroundColor();");
        this.exec("javascript:RE.removeTextHighlight();");
        Log.d("testRicheditor", "clearTextBackgroundColor: ");
    }
}

